import { test, expect } from '@playwright/test'
import Login from '../Pages/Login'
import LoginCredentials from '../Test-Data/LoginCredentials.json' with {type: 'json'}
import Purchase from '../Pages/Purchase'
import {EXPECTED_URL} from '../Utils/Constants.js'

test.beforeEach(async({page})=>{ 
    await page.goto('/') }
)
for (const data of LoginCredentials) {

    // test(` Verifying a successfull purchase of mobile phone with user name as ${data.usernameVal} and password as ${data.passwordVal}`, async ({ page }) => {

    //     await page.goto('https://demoblaze.com/')
    //     page.content('STORE')
    //     const LoginOb = new Login(page)
    //     LoginOb.LoginLink()
    //     await LoginOb.valid_username_valid_password(data.usernameVal, data.passwordVal)
    //     const PurchaseOb = new Purchase(page)
    //     await PurchaseOb.MobPurchaseflow()

    //     page.on('Product added.', dialog => dialog.accept())

    // })


    test(` complete the purchase of  mobile of user ${data.usernameVal} and ${data.passwordVal}`, async ({ page }) => {
      //  await page.goto('https://demoblaze.com/')
        await expect(page.locator('body')).toContainText('STORE')

        const LoginOb = new Login(page)
        await LoginOb.LoginLink()
        		await LoginOb.loginFunctionality(data.usernameVal, data.passwordVal)

        //await LoginOb.valid_username_valid_password(data.usernameVal, data.passwordVal)
       page.on('dialog', dialog => dialog.accept());

        const PurchaseOb = new Purchase(page)
        await PurchaseOb.MobPurchaseflow()
        page.on('Product added.', dialog => dialog.accept())
        await PurchaseOb.CompletePurchaseofMobile()
        await PurchaseOb. FillThedata(PurchaseOb.FullnameVal,PurchaseOb.countryVal,PurchaseOb.cityVal,PurchaseOb.cardVal,PurchaseOb.monthVal,PurchaseOb.yearval)
        await PurchaseOb.ConfirmOder()

    })
    test(` Verifying a successfull purchase of monitor with user name as ${data.usernameVal} and password as ${data.passwordVal}`, async ({ page }) => {

       // await page.goto('https://demoblaze.com/')
        page.content('STORE')
        const LoginOb = new Login(page)
        LoginOb.LoginLink()
        await LoginOb.valid_username_valid_password(data.usernameVal, data.passwordVal)

        const PurchaseOb = new Purchase(page)
        await PurchaseOb.MonitorPurchaseflow()
        page.on('Product added.', dialog => dialog.accept())
    })


      test.only(` Verifying a successfull purchase of a random product with user name as ${data.usernameVal} and password as ${data.passwordVal}`, async ({ page }) => {

      //  await page.goto('https://demoblaze.com/')
        page.content('STORE')
        const LoginOb = new Login(page)
        LoginOb.LoginLink()
        await LoginOb.valid_username_valid_password(data.usernameVal, data.passwordVal)
        const PurchaseOb = new Purchase(page)
        await PurchaseOb.RandomPurchaseflow()
        page.on('Product added.', dialog => dialog.accept())
    })


}
