
 
 export default class Login {
    constructor (page){
    this.page =page
    this.loginLink= page.getByRole('link',{name :'Log in'})
    this.username= page.locator('#loginusername')
    this.password=page.locator('#loginpassword')
    this.LoginBtn=page.locator('#logInModal').getByRole('Button',{name:'Log in'})
        //   const testData = new TestDataGenerator()
        //       this.UsernameVal = testData.generateUsername()
        //       this.passwordVal = testData.generatePassword(6)

    this.logoutBtn = page.getByRole('link',{name :'Log out',exact :true})    

    // locator 
    }

async LoginLink (){ 
        await this.loginLink.click()

}
// one function is enough , we can change the parameters in spec.js file

   async LoginFunctionality(usernameVal,passwordVal){
        await this.username.fill(usernameVal)
        await this.password.fill(passwordVal)
        await this.LoginBtn.click()
    }

    // the following functions are commented out because we can use the above function to perform all the login scenarios by changing the parameters in spec.js file. This will reduce code duplication and make the code more maintainable.
   /* async empty_username_Password(usernameVal,passwordVal) {
        await this.username.fill('')
        await this.password.fill ('')
        await this.LoginBtn.click()

    }

    async invalid_username_valid_password(passwordVal){
        await this.username.fill('@222')
        await this.password.fill(passwordVal)
                await this.LoginBtn.click()

        
    }

    async valid_username_invalid_password(usernamVal){
         await this.username.fill(usernamVal)
        await this.password.fill('abcd')
                await this.LoginBtn.click()

        
    }
    async invalid_username_invalid_password(){
        await this.username.fill('kjhl')
        await this.password.fill('abcd')

                await this.LoginBtn.click()

        
    }



    // async valid_username_valid_password(usernamVal,passwordVal){
    //     await this.username.fill(usernamVal)
    //     console.log(usernamVal)

    //     await this.password.fill(passwordVal)
    //     console.log(passwordVal)

    //             await this.LoginBtn.click()

        
    // }
    async valid_username_valid_password(usernameVal, passwordVal) {
    await this.username.fill(usernameVal)
    await this.password.fill(passwordVal)
    await this.LoginBtn.click()
}
*/


    async logout(){
        await this.logoutBtn.click()

}
   async getURL(){
        return this.page.url()
        // return this.page.url() is used to get the current URL of the page. It returns a promise that resolves to a string representing the URL of the page.
        // this return means that the function getURL() will return the current URL of the page when it is called. This can be useful for verifying that the user has been redirected to the correct page after logging in or performing other actions on the website.
    }
 async DialogAccept(){
        this.page.on('dialog', dialog => dialog.accept());
    }

 }